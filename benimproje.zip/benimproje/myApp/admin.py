from django.contrib import admin
from myApp.models import *
# Register your models here.
admin.site.register(Yeni)
