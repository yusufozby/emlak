const modal = document.querySelector(".modal-container");

const openModal = () =>{
   modal.classList.add("show-modal");
}
const closeModal = () => {
    modal.classList.remove("show-modal");
}
const focusedSearchBar = (id,spanId) => {
  const focusedInput = document.getElementById(id);
  const focusedPlaceholder = document.getElementById(spanId);
  focusedInput.classList.add("focused-text");
  focusedPlaceholder.style.color = "#0000CD"
  focusedPlaceholder.classList.add("focused-placeholder");
}
const focusedOutSearchBar = (id,spanId) => {
    const focusedInput = document.getElementById(id);
    const focusedPlaceholder = document.getElementById(spanId);
   if(focusedInput.value.length == 0) {
    
    focusedPlaceholder.classList.remove("focused-placeholder");  
          
   }
   focusedPlaceholder.style.color = "#a0a0a0"
    focusedInput.classList.remove("focused-text");
}
const openMobileSearch = () => {
    const mobileSearch = document.querySelector(".mobile-search-container");
   
    mobileSearch.classList.add("search-mobile-opened")
    document.querySelector(".search-mobile").focus();
}
const closeMobileSearch = () => {
    const mobileSearchContainer = document.querySelector(".mobile-search-container");
    mobileSearchContainer.classList.remove("search-mobile-opened");
    document.querySelector(".search-mobile").value = "";
   
}
 

const guessTypes = ["yasli","yetiskin","cocuk","bebek"];




const x = Number(document.getElementById("houseFiyat").innerHTML.replace(/₺/g,""));


const yasli = x*0.15;
const cocuk = x*0.1;
const bebek = x*0.2;
const yetiskin = x*0.05;

document.getElementById("houseKDV").innerHTML ="₺" +(x*0.14).toFixed(0);
document.getElementById("houseToplam").innerHTML = "₺"+(x*1.14).toFixed(0);

function arttir(guessId){
var t =  document.getElementById(guessId).innerHTML


let local = document.getElementById("houseFiyat").innerHTML.replace(/₺/g,"");
local = Number(local)
t = Number(t);      
t += 1;

document.getElementById(guessId).innerHTML = t;


for(var i = 0; i < guessTypes.length;i++){
if(guessTypes[i] === guessId) {
    console.log(eval(guessId))
    local += eval(guessId); 
}  
}
document.getElementById("houseFiyat").innerHTML = "₺"+local;

let houseToplam = document.getElementById("houseToplam");
document.getElementById("houseToplam").innerHTML = local+Number(document.getElementById("houseKDV").innerHTML.replace(/₺/g,""));
document.getElementById("houseToplam").innerHTML = "₺"+houseToplam.innerHTML;


}



function azalt(guessId){
    var t =  document.getElementById(guessId).innerHTML
    let local = document.getElementById("houseFiyat").innerHTML.replace(/₺/g,"");
    local = Number(local)
    t = Number(t);
    if(t > 0 ){
    t -= 1;
    document.getElementById(guessId).innerHTML = t;
    console.log(guessId);
   for(var i = 0; i < guessTypes.length;i++){
    if(guessTypes[i] === guessId) {
        console.log(eval(guessId))
        local -= eval(guessId); 
    }  
   }
   document.getElementById("houseFiyat").innerHTML ="₺"+local;



   }
let houseToplam = document.getElementById("houseToplam");
document.getElementById("houseToplam").innerHTML = local+Number(document.getElementById("houseKDV").innerHTML.replace(/₺/g,""));
document.getElementById("houseToplam").innerHTML = "₺"+houseToplam.innerHTML;
}
function showDetails(){
    alert(`Alıcı:Yusuf\nToplam Fiyat : ${document.getElementById("houseToplam").innerHTML}`)
}
